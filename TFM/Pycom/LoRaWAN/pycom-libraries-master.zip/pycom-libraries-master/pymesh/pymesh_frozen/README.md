# Pymesh micropython code

This project exemplifies the use of Pycom's proprietary LoRa Mesh network - **Pymesh**.
These scripts were created and tested on Lopy4 and Fipy, using the Pymesh binary release.

Official Pymesh docs: https://docs.pycom.io/pymesh/

Forum Pymesh announcements: https://forum.pycom.io/topic/4449/pymesh-updates
